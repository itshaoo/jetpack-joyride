#error This file is only for documentation purposes only

/**
 * @brief %Core functionality of the framework
 */
namespace Core {}
